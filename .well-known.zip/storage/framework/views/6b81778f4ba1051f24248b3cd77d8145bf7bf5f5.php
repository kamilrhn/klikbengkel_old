<div class="header pb-8 pt-5 pt-md-8" style="background-color:#ed1c24;">
    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center">
                <div class="col-lg-6 col-7">
                    <h6 class="h2 text-white d-inline-block mb-0">History Service</h6>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\apps-bengkel\resources\views/layouts/headers/historyGroup.blade.php ENDPATH**/ ?>