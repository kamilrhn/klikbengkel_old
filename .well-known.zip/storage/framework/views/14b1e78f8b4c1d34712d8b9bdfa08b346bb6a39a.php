<div class="main">
    <div class="main-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="panel">
                        <div class="panel-heading"></div>
                        <div class="panel-body">
                            <article>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="float-sm-left">
                                            <h1 style="font-size:50px; text-align:center; font-weight:bolder;"></i><i class="fas fa-gear fa-spin"></i></h1>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="float-sm-right">
                                            <h1 style="font-size:50px; text-align:center; font-weight:bolder;"><i class="fas fa-gear fa-spin"></i></h1>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <h1 style="font-size:50px; text-align:center; font-weight:bolder;">Launching Soon!</h1>
                                <div>
                                    <h3 style="font-size:30px; text-align:center;">The webpage you&rsquo;re looking for is under development. Come back later! <i class="far fa-thumbs-up"></i></h3>
                                    <br><h3 style="font-size:20px; text-align:right;">&mdash; PT. Surya Cakra Buana</h3>
                                </div>
                                <br><br>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="float-sm-left">
                                            <h1 style="font-size:50px; text-align:center; font-weight:bolder;"></i><i class="fas fa-gear fa-spin"></i></h1>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="float-sm-right">
                                            <h1 style="font-size:50px; text-align:center; font-weight:bolder;"><i class="fas fa-gear fa-spin"></i></h1>
                                        </div>
                                    </div>
                                </div>
                                <br>
                            </article>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\apps-bengkel\resources\views/404.blade.php ENDPATH**/ ?>