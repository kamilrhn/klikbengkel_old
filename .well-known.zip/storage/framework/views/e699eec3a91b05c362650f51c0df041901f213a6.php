<script src="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/js/bootstrap-editable.min.js"></script>
<script src="https://code.highcharts.com/highcharts.js"></script>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.headers.cards', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="container-fluid mt--7">
       
        <div class="row mt--6">
	        <?php if(Auth::user()->isAsman() || Auth::user()->isPusat() || Auth::user()->isAdmin()): ?>
            <div class="col-xl-6">
                <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col">
                                <h3 class="mb-0">History Budget <?php echo e(\Carbon\Carbon::now()->format('M Y')); ?></h3>
                            </div>
                            <div class="col float-right">
                               <span class="text-black mb--3">
                                   <strong>Total Budget</strong>    : Rp. <?php echo e(number_format($budget_awal)); ?> <br>
                                   <strong>Sisa Budget</strong>     : Rp. <?php echo e(number_format($sisa_budget)); ?>

                               </span>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <ul class="card">
                            <?php $__currentLoopData = $budget; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-6">
                                        <div class="float-sm-left" style="margin-left:-45px;">
                                            <h4><strong>Area <?php echo e($b->kode_area); ?> <br> <?php echo e(date('F Y', strtotime($b->bulan))); ?></strong></h4>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="col text-right">
                                            <span>
                                                Budget Awal : Rp.<?php echo e(number_format($b->budget_awal)); ?> <br>
                                                Sisa Budget : Rp.<?php echo e(number_format($b->sisa_budget)); ?>

                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <div class="card-footer">
                        <div class="text-center">
                            <?php if( request()->route()->uri == 'home/ALL' ): ?>
                            <h3><a href="<?php echo e(route('detailpusat.budget')); ?>">Lihat Lebih Banyak</a></h3>
                            <?php else: ?>
                            <h3><a href="<?php echo e(route('distribusi.budget', request()->segment(count(request()->segments())))); ?>">Lihat Lebih Banyak</a></h3>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <div class="col-xl-6">
                <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col">
                                <h3 class="mb-0">Status Pekerjaan</h3>
                            </div>
                            <div class="col text-right">
                                <?php if(Auth::user()->isAdmin()): ?>
                                <a class="btn btn-sm btn-primary" style="background-color:#808080;" href="<?php echo e(route('request.history')); ?>">See all</a>
                                <?php elseif(Auth::user()->isAsman()): ?>
                                <a class="btn btn-sm btn-primary" style="background-color:#808080;" href="<?php echo e(route('request.historyarea', Auth::user()->resp)); ?>">See all</a>
                                <?php elseif(Auth::user()->isDispatcher()): ?>
                                <a class="btn btn-sm btn-primary" style="background-color:#808080;" href="<?php echo e(route('request.historypool', Auth::user()->resp)); ?>">See all</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <ul class="card">
                            <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-6">
                                        <div class="float-sm-left" style="margin-left:-45px;">
                                            <h4><strong><?php echo e($s->nopol); ?></strong></h4>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="float-sm-right">
                                        <?php if($s->status == 'Waiting'): ?>
                                        <span class="badge badge-danger" style="color:#white">Waiting</span>
                                        <?php elseif($s->status == 'On Service'): ?>
                                        <span class="badge badge-info" style="color:#white">On Service</span>
                                        <?php elseif($s->status == 'On Warranty'): ?>
                                        <span class="badge badge-warning" style="color:#white">On Warranty</span>
                                        <?php elseif($s->status == 'Done'): ?>
                                        <span class="badge badge-primary" style="color:#white">Done</span>
                                        <?php elseif($s->status == 'Decline'): ?>
                                        <span class="badge badge-danger" style="color:#white">Declined</span>
                                        <?php else: ?>
                                        <td></td>
                                        <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-xl-6">
                <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col">
                                <h3 class="mb-0">Diagram Kendaraan</h3>
                            </div>
                            <div class="col text-right">
                                <?php if(Auth::user()->isAdmin()): ?>
                                <a class="btn btn-sm btn-primary" style="background-color:#808080;" href="<?php echo e(route('request.history')); ?>">See all</a>
                                <?php elseif(Auth::user()->isAsman()): ?>
                                <a class="btn btn-sm btn-primary" style="background-color:#808080;" href="<?php echo e(route('request.historyarea', Auth::user()->resp)); ?>">See all</a>
                                <?php elseif(Auth::user()->isDispatcher()): ?>
                                <a class="btn btn-sm btn-primary" style="background-color:#808080;" href="<?php echo e(route('request.historypool', Auth::user()->resp)); ?>">See all</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <ul class="card">
                            <div id="kendaraan"></div>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-xl-6 mb-5 mb-xl-0">
                <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col">
                                <h3 class="mb-0">Plat B / Plat Lokal</h3>
                            </div>
                            <div class="col text-right">
                                <?php if(Auth::user()->isAdmin()): ?>
                                <a class="btn btn-sm btn-primary" style="background-color:#808080;" href="<?php echo e(route('manage.kendaraan')); ?>">See all</a>
                                <?php elseif(Auth::user()->isAsman()): ?>
                                <a class="btn btn-sm btn-primary" style="background-color:#808080;" href="<?php echo e(route('manage.kendaraanarea', Auth::user()->resp)); ?>">See all</a>
                                <?php elseif(Auth::user()->isDispatcher()): ?>
                                <a class="btn btn-sm btn-primary" style="background-color:#808080;" href="<?php echo e(route('manage.kendaraanpool', Auth::user()->resp)); ?>">See all</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div id="plat"></div>
                    </div>
                </div>
            </div>
        </div>

        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<script type="text/javascript">
Highcharts.chart('plat', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: 'Plat B/Plat Lokal'
    },
    credits: {
        enabled : false
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f} % of Total </b>',

    },
    accessibility: {
        point: {
            valueSuffix: '%'
        }
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '{point.y1:.1f} % = {point.y:.f} Kendaraan'
            },
            showInLegend: true
        },
        point: {
        events: {
            click: function(){
                window.location.href = this.link;
            }
        }
    }
    },
    series: [{
        name: 'Plat B',
        colorByPoint: true,
        data: [{
            name: 'Plat B',
            y: <?php echo json_encode($platb); ?>,
            y1: <?php echo json_encode($pplatb); ?>,
            sliced: true,
            selected: true
        }, {
            name: 'Plat Lokal',
            y: <?php echo json_encode($lokal); ?>,
            y1: <?php echo json_encode($plokal); ?>,
            sliced: true,
            selected: true
        }]
    }]
});
Highcharts.chart('kendaraan', {
    chart: {
        type: 'column'
    },
    credits: {
        enabled : false
    },
    title: {
        text: 'Diagram Kendaraan'
    },
    accessibility: {
        announceNewData: {
            enabled: true
        }
    },
    xAxis: {
        type: 'category'
    },
    yAxis: {
        title: {
            text: 'Total'
        }

    },
   
    plotOptions: {
        series: {
            borderWidth: 0,
            dataLabels: {
                enabled: true,
                format: '{point.y:.0f} Kendaraan'
            }
        }
    },

    tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.f}<br/>'
    },

    series: [
        {
            name: "Diagram Kendaraan",
            colorByPoint: true,
            data: [
                {
                    name: "Jumlah Kendaraan",
                    y: <?php echo json_encode($kendaraan); ?>,
                    y1: <?php echo json_encode($kendaraan); ?>

                },
                {
                    name: "On Service",
                    y: <?php echo json_encode($serviceOngoing); ?>,
                    y1: <?php echo json_encode($serviceOngoing); ?>

                },
                {
                    name: "On Warranty",
                    y: <?php echo json_encode($serviceOnwarran); ?>,
                    y1: <?php echo json_encode($serviceOnwarran); ?>

                },
                {
                    name: "Done",
                    y: <?php echo json_encode($serviceDone); ?>,
                    y1: <?php echo json_encode($serviceDone); ?>

                },
            ]
        }
    ],
   
});
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('argon')); ?>/vendor/chart.js/dist/Chart.min.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/vendor/chart.js/dist/Chart.extension.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apps-bengkel\resources\views/home/dashboard.blade.php ENDPATH**/ ?>