
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.headers.requestService', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid mt--7">
   <div class="row">
      <div class="col-xl-12">
         <div class="card">
            <div class="card-header">
               <div class="row align-items-center">
                  <div class="col-8">
                     <h3 class="mb-0">Input Nopol </h3>
                  </div>
               </div>
            </div>
            <div class="card-body">
               <form  action="<?php echo e(route('store.service')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                  <div class="row">
                     <div class="col-md-12">
                        <div class="form-group">
                           <label class="form-control-label" for="input-address">Nopol*</label>
                           <input id="vehicle" name="nopol" class="form-control" placeholder="Type to Search Nopol (ex: B1234ABC)" list="datalistOptions">
                           <datalist id="datalistOptions">
                                <?php $__currentLoopData = $kendaraan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option name="nopol" value="<?php echo e($k->nopol); ?>"><?php echo e($k->nopol); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </datalist>
                        </div>
                     </div>
                  </div>
                  <div class="row">
                      <div class="col-5"></div>
                      <div class="col-2">
                            <button type="submit" style="color:white; text-align:center;background-color:#808080;"  class="btn btn-md btn-primary">INPUT NOPOL</button>
                      </div>
                      <div class="col-5"></div>
                  </div>
               </form>
            </div>
         </div>
      </div>
   </div>
   <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#previewImg').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#uploadImg").change(function(){
        readURL(this);
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apps-bengkel\resources\views/req-service/ceknopol.blade.php ENDPATH**/ ?>