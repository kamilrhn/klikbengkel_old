<nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light bg-white" id="sidenav-main">
    <div class="container-fluid">
        <!-- Toggler -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <!-- Brand -->
        <a class="navbar-brand pt-0" href="#">
            <img src="<?php echo e(asset('argon')); ?>/img/brand/klikbengkel.png" class="navbar-brand-img" alt="...">
        </a>
        <!-- User -->
        <ul class="nav align-items-center d-md-none">
            <li class="nav-item dropdown">
                <a class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <div class="media align-items-center">
                        <span class="avatar avatar-sm rounded-circle">
                        <img alt="Image placeholder" src="<?php echo e(asset('argon')); ?>/img/theme/team-1-800x800.jpg">
                        </span>
                    </div>
                </a>
                <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
                    <div class=" dropdown-header noti-title">
                        <h6 class="text-overflow m-0"><?php echo e(__('Welcome!')); ?></h6>
                    </div>
                    <a href="<?php echo e(route('profile.edit')); ?>" class="dropdown-item">
                        <i class="ni ni-single-02"></i>
                        <span><?php echo e(__('My profile')); ?></span>
                    </a>
                    <a href="#" class="dropdown-item">
                        <i class="ni ni-settings-gear-65"></i>
                        <span><?php echo e(__('Settings')); ?></span>
                    </a>
                    <a href="#" class="dropdown-item">
                        <i class="ni ni-calendar-grid-58"></i>
                        <span><?php echo e(__('Activity')); ?></span>
                    </a>
                    <a href="#" class="dropdown-item">
                        <i class="ni ni-support-16"></i>
                        <span><?php echo e(__('Support')); ?></span>
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="<?php echo e(route('logout')); ?>" class="dropdown-item" onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">
                        <i class="ni ni-user-run"></i>
                        <span><?php echo e(__('Logout')); ?></span>
                    </a>
                </div>
            </li>
        </ul>
        <!-- Collapse -->
        <div class="collapse navbar-collapse" id="sidenav-collapse-main">
            <!-- Collapse header -->
            <div class="navbar-collapse-header d-md-none">
                <div class="row">
                    <div class="col-6 collapse-brand">
                        <a href="#">
                            <img src="<?php echo e(asset('argon')); ?>/img/brand/klikbengkel.png">
                        </a>
                    </div>
                    <div class="col-6 collapse-close">
                        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle sidenav">
                            <span></span>
                            <span></span>
                        </button>
                    </div>
                </div>
            </div>
            <!-- Form -->
            <form class="mt-4 mb-3 d-md-none">
                <div class="input-group input-group-rounded input-group-merge">
                    <input type="search" class="form-control form-control-rounded form-control-prepended" placeholder="<?php echo e(__('Search')); ?>" aria-label="Search">
                    <div class="input-group-prepend">
                        <div class="input-group-text">
                            <span class="fa fa-search"></span>
                        </div>
                    </div>
                </div>
            </form>
            <!-- Navigation -->
           
            <ul class="navbar-nav">
                <li class="nav-item">
                    <?php if(Auth::user()->isAdmin() || Auth::user()->isPusat()): ?>
                    <a class="nav-link" href="<?php echo e(route('home')); ?>">
                    <?php elseif(Auth::user()->isAsman()): ?>
                    <a class="nav-link" href="<?php echo e(route('home.area', Auth::user()->resp)); ?>">
                    <?php elseif(Auth::user()->isDispatcher()): ?>
                    <a class="nav-link" href="<?php echo e(route('home.pool', Auth::user()->resp)); ?>">
                    <?php endif; ?>
                        <i class="ni ni-tv-2 text-red"></i> <span class="nav-link-text" style="color: #f4645f;">Dashboard</span>
                    </a>
                </li>
                <!-- <li class="nav-item">
                    <a class="nav-link active" href="#navbar-examples" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="navbar-examples">
                        <i class="fab fa-laravel" style="color: #f4645f;"></i>
                        <span class="nav-link-text" style="color: #f4645f;"><?php echo e(__('Laravel Examples')); ?></span>
                    </a>

                    <div class="collapse show" id="navbar-examples">
                        <ul class="nav nav-sm flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('profile.edit')); ?>">
                                    <?php echo e(__('User profile')); ?>

                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('user.index')); ?>">
                                    <?php echo e(__('User Management')); ?>

                                </a>
                            </li>
                        </ul>
                    </div>
                </li> -->

                <!-- <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('icons')); ?>">
                        <i class="ni ni-planet text-blue"></i> <?php echo e(__('Request Service')); ?>

                    </a>
                </li> -->
                
                <li class="nav-item">
                    <a class="nav-link " href="#navbar-components" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="navbar-components">
                        <i class="ni ni-settings text-red" style="color: #f4645f;"></i>
                        <span class="nav-link-text" style="color: #f4645f;">Service</span>
                    </a>
                    <div class="collapse" id="navbar-components">
                        <ul class="nav nav-sm flex-column">
                            <?php if(Auth::user()->isAdmin() || Auth::user()->isDispatcher()): ?>
                            <li class="nav-item">
                                <?php if(Auth::user()->isAdmin()): ?>
                                <a class="nav-link"  href="<?php echo e(route('404')); ?>">
                                <?php else: ?>
                                <a class="nav-link"  href="<?php echo e(route('request.cek', Auth::user()->resp)); ?>">
                                <?php endif; ?>
                                    Request Service
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(Auth::user()->isAdmin() || Auth::user()->isDispatcher()): ?>
                            <li class="nav-item">
                                <?php if(Auth::user()->isAdmin()): ?>
                                <a class="nav-link"  href="<?php echo e(route('404')); ?>">
                                <?php else: ?>
                                <a class="nav-link"  href="<?php echo e(route('request.cekurg', Auth::user()->resp)); ?>">
                                <?php endif; ?>
                                    Request Urgent Service
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(Auth::user()->isAdmin() || Auth::user()->isDispatcher()): ?>
                            <li class="nav-item">
                                <?php if(Auth::user()->isAdmin()): ?>
                                <a class="nav-link" href="<?php echo e(route('404')); ?>">
                                <?php else: ?>
                                <a class="nav-link"  href="<?php echo e(route('request.cekpart', Auth::user()->resp)); ?>">
                                <?php endif; ?>
                                    Ganti Part
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(Auth::user()->isAdmin() || Auth::user()->isAsman()): ?>
                            <li class="nav-item">
                                <?php if(Auth::user()->isAdmin()): ?>
                                <a class="nav-link"  href="<?php echo e(route('404')); ?>">
                                <?php else: ?>
                                <a class="nav-link"  href="<?php echo e(route('request.approval', Auth::user()->resp)); ?>">
                                <?php endif; ?>
                                    Approval Service
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(Auth::user()->isAdmin() || Auth::user()->isAsman()): ?>
                            <li class="nav-item">
                                <?php if(Auth::user()->isAdmin()): ?>
                                <a class="nav-link"  href="<?php echo e(route('404')); ?>">
                                <?php else: ?>
                                <a class="nav-link"  href="<?php echo e(route('acc.cancel', Auth::user()->resp)); ?>">
                                <?php endif; ?>
                                    Approval Cancel Service
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(Auth::user()->isAdmin() || Auth::user()->isDispatcher()): ?>
                            <li class="nav-item">
                                <?php if(Auth::user()->isAdmin()): ?>
                                <a class="nav-link"  href="<?php echo e(route('404')); ?>">
                                <?php else: ?>
                                <a class="nav-link"  href="<?php echo e(route('complete.pool', Auth::user()->resp)); ?>">
                                <?php endif; ?>
                                    Completion Service
                                </a>
                            </li>
                            <?php endif; ?>
                            <li class="nav-item">
                                <?php if(Auth::user()->isPusat()): ?>
                                <a class="nav-link" href="<?php echo e(route('request.history')); ?>">
                                <?php elseif(Auth::user()->isAdmin()): ?>
                                <a class="nav-link" href="<?php echo e(route('request.historygroup')); ?>">
                                <?php elseif(Auth::user()->isAsman()): ?>
                                <a class="nav-link" href="<?php echo e(route('request.historyarea', Auth::user()->resp)); ?>">
                                <?php elseif(Auth::user()->isDispatcher()): ?>
                                <a class="nav-link" href="<?php echo e(route('request.historypool', Auth::user()->resp)); ?>">
                                <?php endif; ?>
                                    History Service
                                </a>
                            </li>
                            <?php if(Auth::user()->isAdmin() || Auth::user()->isDispatcher()): ?>
                            <li class="nav-item">
                                <?php if(Auth::user()->isAdmin()): ?>
                                <a class="nav-link"  href="<?php echo e(route('404')); ?>">
                                <?php else: ?>
                                <a class="nav-link"  href="<?php echo e(route('cancel.list', Auth::user()->resp)); ?>">
                                <?php endif; ?>
                                    Cancel Service
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </li>
                <?php if(Auth::user()->isDispatcher()): ?>
                <li class="nav-item ">
                    <a class="nav-link" href="<?php echo e(route('reminder.index', Auth::user()->resp)); ?>">
                    <i class="fas fa-bell-slash text-red" aria-hidden="true"></i> <span class="nav-link-text" style="color: #f4645f;">Reminder Service <span class="badge badge-info right">1</span></span>
                    </a>
                </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link " href="#navbar-invoice" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="navbar-invoice">
                        <?php if(Auth::user()->isDispatcher()): ?>
                        <i class="far fa-credit-card text-red" style="color: #f4645f;"></i>
                        <span class="nav-link-text" style="color: #f4645f;">Payment</span> 
                        <?php else: ?>
                        <i class="fa fa-file-invoice-dollar text-red" style="color: #f4645f;"></i>
                        <span class="nav-link-text" style="color: #f4645f;">Invoice</span> 
                        <?php endif; ?>
                    </a>
                    <div class="collapse" id="navbar-invoice">
                        <ul class="nav nav-sm flex-column">
                            <?php if(Auth::user()->isAdmin() || Auth::user()->isAsman() || Auth::user()->isPusat()): ?>
                            <li class="nav-item">
                                <?php if(Auth::user()->isAdmin() || Auth::user()->isPusat()): ?>
                                <a class="nav-link" href="<?php echo e(route('invoice.index')); ?>">
                                <?php elseif(Auth::user()->isAsman()): ?>
                                <a class="nav-link" href="<?php echo e(route('invoice.indexarea', Auth::user()->resp)); ?>">
                                <?php endif; ?>
                                    List Invoice
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(Auth::user()->isDispatcher()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('payment.list', Auth::user()->resp)); ?>">
                                    Submission Payment
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('payment.paid', Auth::user()->resp)); ?>">
                                    Confirmation Payment
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(Auth::user()->isAdmin()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('payment.approval')); ?>">
                                    Approval Payment
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(Auth::user()->isAdmin()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('payment.accept')); ?>">
                                    Confirm Payment
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </li>
                <?php if(Auth::user()->isAdmin() || Auth::user()->isAsman()): ?>
                <li class="nav-item ">
                    <?php if(Auth::user()->isAdmin()): ?>
                    <a class="nav-link" href="#">
                    <?php elseif(Auth::user()->isAsman()): ?>
                    <a class="nav-link" href="#">
                    <?php endif; ?>
                    <i class="fa fa-info-circle text-red" aria-hidden="true"></i> <span class="nav-link-text" style="color: #f4645f;">Report</span>
                    </a>
                </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link " href="#navbar-pages" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="navbar-pages">
                        <i class="fas fa-wallet text-red" style="color: #f4645f;"></i>
                        <span class="nav-link-text" style="color: #f4645f;">Budget</span>
                    </a>
                    <div class="collapse" id="navbar-pages">
                        <ul class="nav nav-sm flex-column">
                            <?php if(Auth::user()->isAsman()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('release.budget', Auth::user()->resp)); ?>">
                                    Release Budget
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('distribusi.budget', Auth::user()->resp)); ?>">
                                    Distribusi Budget
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(Auth::user()->isAsman() || Auth::user()->isDispatcher()): ?>
                            <li class="nav-item">
                                <?php if(Auth::user()->isAsman()): ?>
                                <a class="nav-link" href="<?php echo e(route('topup.budget', Auth::user()->resp)); ?>">
                                <?php else: ?>
                                <a class="nav-link" href="<?php echo e(route('history.budget', Auth::user()->resp)); ?>">
                                <?php endif; ?>
                                    <?php if(Auth::user()->isAsman()): ?>
                                    Top-Up Budget
                                    <?php else: ?>
                                    History Budget
                                    <?php endif; ?>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(Auth::user()->isPusat() || Auth::user()->isAdmin()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('detailpusat.budget')); ?>">
                                    Detail Budget
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#navbar-examples" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="navbar-examples">
                        <i class="fa fa-database text-red" aria-hidden="true"></i>
                        <span class="nav-link-text" style="color: #f4645f;">Manage</span>
                    </a>
                    <div class="collapse" id="navbar-examples">
                        <ul class="nav nav-sm flex-column">
                            <!-- <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('manage.area')); ?>">
                                    Area
                                </a>
                            </li> -->
                            <li class="nav-item">
                                <?php if(Auth::user()->isAdmin() || Auth::user()->isPusat()): ?>
                                <a class="nav-link" href="<?php echo e(route('manage.kendaraan')); ?>">
                                <?php elseif(Auth::user()->isAsman()): ?>
                                <a class="nav-link" href="<?php echo e(route('manage.kendaraanarea', Auth::user()->resp)); ?>">
                                <?php elseif(Auth::user()->isDispatcher()): ?>
                                <a class="nav-link" href="<?php echo e(route('manage.kendaraanpool', Auth::user()->resp)); ?>">
                                <?php endif; ?>
                                    Kendaraan
                                </a>
                            </li>
                            <?php if(Auth::user()->isAsman()): ?>
                            <li class="nav-item">
                                <a class="nav-link" target="_blank" href="http://mymonalisa.id/">
                                    Monalisa
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(Auth::user()->isAsman() || Auth::user()->isAdmin() || Auth::user()->isDispatcher()): ?>
                            <li class="nav-item">
                                <?php if(Auth::user()->isAdmin() || Auth::user()->isPusat()): ?>
                                <a class="nav-link" href="<?php echo e(route('manage.bengkel')); ?>">
                                <?php elseif(Auth::user()->isAsman()): ?>
                                <a class="nav-link" href="<?php echo e(route('manage.bengkelarea', Auth::user()->resp)); ?>">
                                <?php elseif(Auth::user()->isDispatcher()): ?>
                                <a class="nav-link" href="<?php echo e(route('manage.bengkelpool', Auth::user()->resp)); ?>">
                                <?php endif; ?>
                                    Bengkel
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(Auth::user()->isAdmin()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="#">
                                    Stok
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(Auth::user()->isAsman()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('manage.service', Auth::user()->resp)); ?>">
                                    Service by Nopol
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(Auth::user()->isAsman() || Auth::user()->isAdmin()): ?>
                            <li class="nav-item">
                                <?php if(Auth::user()->isAsman()): ?>
                                <a class="nav-link" href="<?php echo e(route('manage.nonkhs', Auth::user()->resp)); ?>">
                                <?php else: ?>
                                <a class="nav-link" href="<?php echo e(route('nonkhs.admin')); ?>">
                                <?php endif; ?>
                                    Data Non KHS
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(Auth::user()->isAsman()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('setting.index', Auth::user()->resp)); ?>">
                                    Pengaturan Validasi
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </li>
				<?php if(Auth::user()->isDispatcher()|| Auth::user()->isAsman()): ?>
                <li class="nav-item ">
                    <a class="nav-link" href="https://gsd.mymonalisa.id/public/" target="_blank">
                    <i class="fas fa-bell-slash text-red" aria-hidden="true"></i> <span class="nav-link-text" style="color: #f4645f;">My Monalisa </span>
                    </a>
                </li>
                <?php endif; ?>
                <!-- <li class="nav-item">
                    <a class="nav-link" href="#">
                        <i class="ni ni-circle-08 text-pink"></i> <?php echo e(__('Register')); ?>

                    </a>
                </li> -->
               
            </ul>
            <!-- Divider -->
            <hr class="my-3">
            <!-- Heading -->
            <!-- <h6 class="navbar-heading text-muted">Documentation</h6> -->
            <!-- Navigation -->
            <!-- <ul class="navbar-nav mb-md-3">
                <li class="nav-item">
                    <a class="nav-link" href="https://argon-dashboard-laravel.creative-tim.com/docs/getting-started/overview.html">
                        <i class="ni ni-spaceship"></i> Getting started
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="https://argon-dashboard-laravel.creative-tim.com/docs/foundation/colors.html">
                        <i class="ni ni-palette"></i> Foundation
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="https://argon-dashboard-laravel.creative-tim.com/docs/components/alerts.html">
                        <i class="ni ni-ui-04"></i> Components
                    </a>
                </li>
            </ul> -->
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\apps-bengkel\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>