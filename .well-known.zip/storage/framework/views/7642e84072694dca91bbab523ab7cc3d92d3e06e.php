
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.headers.payment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/vendor/dropzone/dist/min/dropzone.min.js"></script>
<div class="container-fluid mt--7">
    <div class="row mb-4">
       <div class="col-6">
            <div class="card">
                <div class="card-header border-0">
                    <h3 class="mb-0">Detail Service</h3>
                </div>
                <div class="table-responsive px-2 py-2">
                  <table class="table table-bordered mb-2" style="width=100%;">
                     <thead>
                        <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#565656">
                           <th colspan="4">DETAIL SERVICE KHS</th>
                        </tr>
                        <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#565656">
                           
                           <th width="40%">Deskripsi</th>
                           <th width="15%">Qty</th>
                           <th width="20%">Harga</th>
                           <th width="20%">Subtotal</th>
                        </tr>
                     </thead>
                     <tbody>
                        <?php $__currentLoopData = $rinciankhs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center">
                           
                           <td width="40%"><?php echo e($r->keterangan); ?></td>
                           <td width="15%"><?php echo e($r->qty); ?></td>
                           <td width="20%"><?php echo e(number_format($r->harga)); ?></td>
                           <td width="20%"><?php echo e(number_format($r->subtotal)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                     <tfoot>
                        <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#808080">
                           <th colspan="3">Total</th>
                           <th><?php echo e(number_format($totalkhs)); ?></th>
                        </tr>
                     </tfoot>
                  </table>
                  <table class="table table-bordered mb-2" style="width=100%;">
                     <thead>
                        <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#565656">
                           <th colspan="4">DETAIL SERVICE NON KHS</th>
                        </tr>
                        <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#565656">
                           
                           <th width="40%">Deskripsi</th>
                           <th width="15%">Qty</th>
                           <th width="20%">Harga</th>
                           <th width="20%">Subtotal</th>
                        </tr>
                     </thead>
                     <tbody>
                        <?php $__currentLoopData = $rinciannon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center">
                           
                           <td width="40%"><?php echo e($r->keterangan); ?></td>
                           <td width="15%"><?php echo e($r->qty); ?></td>
                           <td width="20%"><?php echo e(number_format($r->harga)); ?></td>
                           <td width="20%"><?php echo e(number_format($r->subtotal)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                     <tfoot>
                        <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#808080">
                           <th colspan="3">Total</th>
                           <th><?php echo e(number_format($totalnon)); ?></th>
                        </tr>
                        <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#808080">
                           <th colspan="3">PPn(10%)</th>
                           <th><?php echo e(number_format($payment->service->ppn)); ?></th>
                        </tr>
                     </tfoot>
                   </table>
                    <table class="table table-bordered" style="width=80%;">
                       <thead>
                          <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#565656">
                             <th colspan="4">TOTAL PEMBAYARAN SERVICE <?php echo e($payment->service->no_service); ?></th>
                          </tr>
                          <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#565656">
                             <th width="40%">Deskripsi</th>
                             <th width="20%">Total</th>
                             <th width="20%">PPn</th>
                             <th width="20%">Grand Total</th>
                          </tr>
                       </thead>
                       <tbody>
                          <tr class="text-center">
                             <td width="40%">Grand Total Service KHS</td>
                             <td width="20%"><?php echo e(number_format($totalkhs)); ?></td>
                             <td width="20%">0</td>
                             <td width="20%"><?php echo e(number_format($totalkhs)); ?></td>
                          </tr>
                          <tr class="text-center">
                             <td width="40%">Grand Total Service Non KHS</td>
                             <td width="20%"><?php echo e(number_format($totalnon)); ?></td>
                             <td width="20%"><?php echo e(number_format($payment->service->ppn)); ?></td>
                             <td width="20%"><?php echo e(number_format($totalnon + $payment->service->ppn)); ?></td>
                          </tr>
                       </tbody>
                       <tfoot>
                          <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#808080">
                             <th colspan="3">Total</th>
                             <th><?php echo e(number_format($payment->service->total)); ?></th>
                          </tr>
                       </tfoot>
                    </table>
                 </div>
            </div>
       </div>
       <div class="col-6">
         <div class="card">
            <div class="card-header border-0">
               <h3 class="mb-0">Foto Nota Service</h3>
            </div>
            <div class="card-body" style="height:750px; ">
               <div class="card-title mb-4">
                  <h4>No. Polisi : <?php echo e($payment->service->nopol); ?></h4>
                  <h4>Nama Bengkel : <?php echo e($payment->service->bengkel); ?></h4>
                  <h4>Jenis Bengkel : <?php echo e($payment->service->jenis_bengkel); ?></h4>
               </div>
               <div class="dz-preview dz-preview-single mt-2">
                  <div class="dz-preview-cover">
                     <?php if($payment->service->foto != NULL): ?>
                     <img src="<?php echo e(asset('payment/'.$payment->file)); ?>" class="dz-preview-img"  id="previewImg" style="height:600px; width:550px;" data-dz-thumbnail>
                     <?php else: ?>
                     <img class="dz-preview-img"  id="previewImg" style="height:250px; width:400px;" data-dz-thumbnail>
                     <?php endif; ?>
                  </div>
               </div>
            </div>
         </div>
      </div>
    </div>
    <div class="row">
       <div class="col">
            <div class="card">
                <div class="card-header border-0">
                    <h3 class="mb-0">Detail Payment</h3>
                </div>
                <div class="card-body text-center border-0">
                    <h4 class="mb-0">Mohon Melakukan Pembayaran No. Service <?php echo e($payment->service->no_service); ?> ke:</h4>
                    <ul class="list-unstyled  mt-4">
                        <li><h3><i class="far fa-credit-card text-red"></i> : <?php echo e($payment->nama_bank); ?> <?php echo e($payment->no_rekening); ?> an. <?php echo e($payment->nama_rekening); ?></h3></li>
                        <li><h3><i class="fas fa-money-bill-wave text-red"></i> : Rp. <?php echo e(number_format($payment->nominal_nota)); ?></h3></li>
                    </ul>
                </div>
                <div class="card-footer py-4">
                    <nav aria-label="...">
                        <div class="float-sm-right">
                            <ul class="pagination mb-0">
                                <li class="page-item">
                                   
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
       </div>
    </div>
    <div class="row mt-4">
      <div class="col-12">
         <?php if($payment->status != 'Accepted'): ?>
         <div class="float-right">
            <a href="<?php echo e(route('payment.decline', $payment->kode_bayar)); ?>" style="color:white;" class="btn btn-danger">Decline</a>
            <a href="<?php echo e(route('payment.approve', $payment->kode_bayar)); ?>"  style="color:white;" class="btn btn-success">Approve</a>
         </div>
         <?php endif; ?>
      </div>
   </div>
    <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apps-bengkel\resources\views/payment/detailpayment.blade.php ENDPATH**/ ?>