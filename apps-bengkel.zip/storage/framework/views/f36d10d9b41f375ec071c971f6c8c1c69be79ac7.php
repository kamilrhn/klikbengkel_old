<div class="header  py-7 py-lg-8" style="background-color:#ed1c24;">
    <div class="container">
        <div class="header-body text-center mb-7">
            <div class="row justify-content-center">
                <div class="col-lg-5 col-md-6">
                    <h1 class="text-white"><?php echo e(__('Selamat Datang di Aplikasi klikbengkel.')); ?></h1>
                </div>
            </div>
        </div>
    </div>
    <div class="separator separator-bottom separator-skew zindex-100">
       
    </div>
</div><?php /**PATH C:\xampp\htdocs\apps-bengkel\resources\views/layouts/headers/guest.blade.php ENDPATH**/ ?>