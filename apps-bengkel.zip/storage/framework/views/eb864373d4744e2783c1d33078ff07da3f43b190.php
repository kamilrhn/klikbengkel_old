
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.adminKendaraan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid mt--7">
   <div class="row">
      <div class="col">
         <div class="card">
            <!-- Card header -->
            <div class="card-header border-0">
              <h3 class="mb-0">Data Kendaraan PT Graha Sarana Duta</h3>
            </div>
            <!-- Light table -->
            <div class="table-responsive">
              <table class="table align-items-center table-flush">
                <thead class="thead-light">
                  <tr>
                    <th scope="col" class="sort" data-sort="name">Nopol</th>
                    <th scope="col" class="sort" data-sort="name">Area</th>
                    <th scope="col" class="sort" data-sort="name">Witel</th>
                    <th scope="col" class="sort" data-sort="name">Pool</th>
                    <th scope="col" class="sort" data-sort="budget">Merk</th>
                    <th scope="col" class="sort" data-sort="status">Users</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody class="list">
                <?php $__currentLoopData = $kendaraan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                     <td><?php echo e($k->nopol); ?></td>
                     <td><?php echo e($k->area); ?></td>
                     <td><?php echo e($k->witel); ?></td>
                     <td><?php echo e($k->pool); ?></td>
                     <td><?php echo e($k->merk); ?> <?php echo e($k->type); ?></td>
                     <td><?php echo e($k->kepemilikan); ?></td>
                     <td>
                        <a href="#" class="btn btn-sm btn-info"><i class="fa fa-eye" aria-hidden="true"></i></a>
                        <a href="#" class="btn btn-sm btn-warning"><i class="ni ni-ruler-pencil"></i></a>
                        <a href="#" class="btn btn-sm btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a>
                     </td>
                 </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            
            <!-- Card footer -->
            <div class="card-footer py-4">
              <nav aria-label="...">
                <div class="float-sm-right">
                  <ul class="pagination mb-0">
                    <li class="page-item">
                      <?php echo e($kendaraan->links()); ?>

                    </li>
                  </ul>
                </div>
              </nav>
            </div>
          </div>
      </div>
   </div>
   <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mywe9397/public_html/klikbengkel.id/resources/views/manage/kendaraanarea.blade.php ENDPATH**/ ?>