
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.headers.budgetPusat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid mt--7">
   <div class="row">
      <div class="col">
         <div class="card">
            <!-- Card header -->
            <div class="card-header border-0">
              <h3 class="mb-0">Data Release Budget</h3>
            </div>
            <!-- Light table -->
            <div class="table-responsive">
              <table class="table align-items-center table-flush">
                <thead class="thead-light">
                  <tr>
                    <th scope="col" class="sort" data-sort="name">Area</th>
                    <th scope="col" class="sort" data-sort="name">Periode</th>
                    <th scope="col" class="sort" data-sort="name">Budget Awal</th>
                    <th scope="col" class="sort" data-sort="name">Budget Terpakai</th>
                    <th scope="col" class="sort" data-sort="name">Budget Sisa</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody class="list">
                <?php $__currentLoopData = $budget; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                    <td>Pool <?php echo e($b->pool); ?></td>
                    <td><?php echo e(date('F Y', strtotime($b->bulan))); ?></td>   
                    <td>Rp.<?php echo e(number_format($b->budget_awal)); ?></td>  
                    <td>Rp.<?php echo e(number_format($b->budget_awal - $b->sisa_budget)); ?></td>  
                    <td>Rp.<?php echo e(number_format($b->sisa_budget)); ?></td>  
                 </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                   <td colspan="2" class="teal darken-1 white-text text-center"><strong>Jumlah</strong></td>
                   <td><strong>Rp. 1234</strong></td>
                   <td><strong>Rp. 1234</strong></td>
                   <td><strong>Rp. 1234</strong></td>
                 </tr>
                </tbody>
              </table>
            </div>
            
            <!-- Card footer -->
            <div class="card-footer py-4">
              <nav aria-label="...">
                <div class="float-sm-right">
                  <ul class="pagination mb-0">
                    <li class="page-item">
                    </li>
                  </ul>
                </div>
              </nav>
            </div>
          </div>
      </div>
   </div>
   <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mywe9397/public_html/klikbengkel.id/resources/views/budget/rincianpusat.blade.php ENDPATH**/ ?>