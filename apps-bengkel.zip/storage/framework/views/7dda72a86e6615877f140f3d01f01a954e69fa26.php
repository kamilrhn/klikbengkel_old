
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.cari', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid mt--7">
   <div class="row">
      <div class="col">
         <div class="card">
            <!-- Card header -->
            <div class="card-header border-0">
              <h3 class="mb-0">Detail Service <?php echo e($service->no_service); ?></h3>
            </div>
            <!-- Light table -->
           <div class="card-body">
               <div class="row">
                   <div class="col-3"></div>
                   <div class="col-6">
                       <div class="card-body">
                            <ul class="list-unstyled list-justify">
                                <li><strong>No Service</strong> <span class="text-right"><?php echo e($service->no_service); ?></span></li>
                                <li><strong>Nopol</strong> <span class="text-right"><?php echo e($service->nopol); ?></span></li>
                            </ul>
                       </div>
                   </div>
                   <div class="col-3"></div>
               </div>
           </div>
            
            <!-- Card footer -->
            <div class="card-footer py-4">
              <nav aria-label="...">
                <div class="float-sm-right">
                  <ul class="pagination mb-0">
                    <li class="page-item">
                      
                    </li>
                  </ul>
                </div>
              </nav>
            </div>
          </div>
      </div>
   </div>
   <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apps-bengkel\resources\views/home/detail.blade.php ENDPATH**/ ?>