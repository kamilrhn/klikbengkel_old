
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.headers.payment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/vendor/dropzone/dist/min/dropzone.min.js"></script>
<div class="container-fluid mt--7">
    <div class="row">
       <div class="col">
            <div class="card">
                <div class="card-header border-0">
                    <h3 class="mb-0">Approval Payment</h3>
                </div>
                <div class="table-responsive">
                    <table class="table align-items-center table-flush">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col" class="sort" data-sort="name">Kode Bayar</th>
                                <th scope="col" class="sort" data-sort="name">Tanggal Pengajuan</th>
                                <th scope="col" class="sort" data-sort="name">No. Service</th>
                                <th scope="col" class="sort" data-sort="budget">Nominal Service</th>
                                <th scope="col" class="sort" data-sort="budget">Nominal Nota</th>
                                <th scope="col" class="sort" data-sort="budget">Profit</th>
                                <th scope="col" class="sort" data-sort="budget">Status</th>
                                <th scope="col" class="sort" data-sort="budget">#</th>
                            </tr>
                        </thead>
                        <tbody class="list">
                            <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($s->payment->kode_bayar); ?></td>
                                <td><?php echo e(date('Y-m-d', strtotime($s->payment->created_at))); ?></td>
                                <td><?php echo e($s->no_service); ?></td>
                                <td><?php echo e(number_format($s->total)); ?></td>
                                <td><?php echo e(number_format($s->payment->nominal_nota)); ?></td>
                                <td><?php echo e(number_format($s->payment->profit)); ?></td>
                                <?php if($s->status == 'Waiting'): ?>
                                <td><span class="badge badge-danger" style="color:#white">Waiting</span></td>
                                <?php elseif($s->status == 'On Service'): ?>
                                <td><span class="badge badge-info" style="color:#white">On Service</span></td>
                                <?php elseif($s->status == 'On Warranty'): ?>
                                <td><span class="badge badge-warning" style="color:#white">On Warranty</span></td>
                                <?php elseif($s->status == 'Done'): ?>
                                <td><span class="badge badge-success" style="color:#white">Done</span></td>
                                <?php elseif($s->status == 'Request Cancel'): ?>
                                <td><span class="badge badge-success" style="color:#white">Request Cancel</span></td>
                                <?php elseif($s->status == 'Waiting Payment Approval'): ?>
                                <td><span class="badge badge-success" style="color:#white">Waiting Payment Approval</span></td>
                                <?php elseif($s->status == 'Payment Accept'): ?>
                                <td><span class="badge badge-success" style="color:#white">Payment Accept</span></td>
                                <?php else: ?>
                                <td><span class="badge badge-danger" style="color:#white">Declined</span></td>
                                <?php endif; ?>
                                <td>
                                    <a href="<?php echo e(route('payment.detail', $s->payment->kode_bayar)); ?>" class="btn btn-sm btn-info"><i class="fas fa-eye"></i> Detail</a>
                                </td>
                            </tr>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer py-4">
                    <nav aria-label="...">
                        <div class="float-sm-right">
                            <ul class="pagination mb-0">
                                <li class="page-item">
                                    <?php echo e($service->links()); ?>

                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
       </div>
    </div>
    <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apps-bengkel\resources\views/payment/paymentApproval.blade.php ENDPATH**/ ?>