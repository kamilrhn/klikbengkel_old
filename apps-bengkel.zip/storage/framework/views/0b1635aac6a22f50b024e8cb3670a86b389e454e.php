
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.headers.approval', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid mt--7">
   <div class="row">
      <div class="col">
         <div class="card">
            <!-- Card header -->
            <div class="card-header border-0">
               <h3 class="mb-0">Approval Service</h3>
            </div>
            <!-- Light table -->
            <div class="table-responsive">
               <table class="table align-items-center table-flush">
                  <thead class="thead-light">
                     <tr>
                        <th scope="col" class="sort" data-sort="name">No. Service</th>
                        <th scope="col" class="sort" data-sort="name">Nopol</th>
                        <th scope="col" class="sort" data-sort="budget">Nama Bengkel</th>
                        <th scope="col" class="sort" data-sort="status">Tanggal Pengajuan</th>
                        <th scope="col" class="sort" data-sort="status">Status</th>
                        <th scope="col">Action</th>
                     </tr>
                  </thead>
                  <tbody class="list">
                     <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                        <td><?php echo e($s->no_service); ?></td>
                        <td><?php echo e($s->nopol); ?></td>
                        <td><?php echo e($s->bengkel); ?></td>
                        <td><?php echo e($s->tanggal); ?></td>
                        <?php if($s->status == 'Waiting'): ?>
                        <td><span class="badge badge-danger" style="color:#white">Waiting</span></td>
                        <?php elseif($s->status == 'On Service'): ?>
                        <td><span class="badge badge-info" style="color:#white">On Service</span></td>
                        <?php elseif($s->status == 'On Warranty'): ?>
                        <td><span class="badge badge-warning" style="color:#white">On Warranty</span></td>
                        <?php elseif($s->status == 'Done'): ?>
                        <td><span class="badge badge-primary" style="color:#white">Done</span></td>
                        <?php else: ?>
                        <td></td>
                        <?php endif; ?>
                        <td>
                           <a href="<?php echo e(route('request.detailapp', $s->no_service)); ?>" class="btn btn-sm btn-info"><i class="fa fa-eye" aria-hidden="true"></i></a>
                           <!-- <a href="#" class="btn btn-sm btn-warning" data-toggle="modal" data-target="#approve-<?php echo e($s->no_service); ?>"><i class="ni ni-ruler-pencil"></i></a> -->
                        </td>
                     </tr>
                     <div class="modal fade" id="approve-<?php echo e($s->no_service); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                           <div class="modal-content">
                              <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel">Approval</h5>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              </div>
                              <div class="modal-body">
                                 <div class="row">
                                    <div class="col-lg-6">
                                       <label class="form-control-label" for="input-address">Nopol</label>
                                       <input type="text" id="input-city" class="form-control" placeholder="Nama Bengkel" value="<?php echo e($s->nopol); ?>" readonly>
                                       <label class="form-control-label" for="input-address">Waktu Pengajuan</label>
                                       <input type="text" id="input-city" class="form-control" placeholder="Nama Bengkel" value="<?php echo e($s->tanggal); ?>" readonly>
                                    </div>
                                    <div class="col-lg-6">
                                       <label class="form-control-label" for="input-address">Nama Bengkel</label>
                                       <input type="text" id="input-city" class="form-control" placeholder="Nama Bengkel" value="<?php echo e($s->bengkel); ?>" readonly>
                                       <label class="form-control-label" for="input-address">Pool</label>
                                       <input type="text" id="input-city" class="form-control" placeholder="Nama Bengkel" value="<?php echo e($s->pool); ?>" readonly>
                                    </div>
                                 </div>
                                 <div class="row mt-4">
                                    <div class="col-lg-3">
                                       <h4><strong>Nama Pekerjaan</strong></h4>
                                    </div>
                                    <div class="col-lg-3">
                                       <h4><strong>Harga</strong></h4>
                                    </div>
                                    <div class="col-lg-3">
                                       <h4><strong>Qty</strong></h4>
                                    </div>
                                    <div class="col-lg-3">
                                       <h4><strong>Subtotal</strong></h4>
                                    </div>
                                 </div>
                                 
                                 <div class="row mt-2">
                                 <?php $__currentLoopData = $s->rincian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-3">
                                       <h5><?php echo e($sr->keterangan); ?></h5>
                                    </div>
                                    <div class="col-lg-3">
                                       <h5><?php echo e($sr->harga); ?></h5>
                                    </div>
                                    <div class="col-lg-3">
                                       <h5><?php echo e($sr->qty); ?></h5>
                                    </div>
                                    <div class="col-lg-3">
                                       <h5><?php echo e($sr->subtotal); ?></h5>
                                    </div>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-9">
                                       <div class="float-right">
                                          <h5><strong>Subtotal</strong></h5>
                                       </div>
                                    </div>
                                    <div class="col-lg-3">
                                       <h5><strong><?php echo e($s->subtotal); ?></strong></h5>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-9">
                                       <div class="float-right">
                                          <h5><strong>PPn</strong></h5>
                                       </div>
                                    </div>
                                    <div class="col-lg-3">
                                       <h5><strong><?php echo e($s->ppn); ?></strong></h5>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-9">
                                       <div class="float-right">
                                          <h5><strong>Grand Total</strong></h5>
                                       </div>
                                    </div>
                                    <div class="col-lg-3">
                                       <h5><strong><?php echo e($s->total); ?></strong></h5>
                                    </div>
                                 </div>
                              </div>
                              <div class="modal-footer mt--3">
                                 <a href="<?php echo e(route('decline.service', $s->no_service)); ?>" style="color:white;" class="btn btn-danger">Decline</a>
                                 <a href="<?php echo e(route('approve.service', $s->no_service)); ?>"  style="color:white;" class="btn btn-success">Approve</a>
                              </div>
                           </div>
                        </div>
                     </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
               </table>
            </div>
            <!-- Card footer -->
            <div class="card-footer py-4">
               <nav aria-label="...">
                  <div class="float-sm-right">
                     <ul class="pagination mb-0">
                        <li class="page-item">
                           <?php echo e($service->links()); ?>

                        </li>
                     </ul>
                  </div>
               </nav>
            </div>
         </div>
      </div>
   </div>
   <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apps-bengkel\resources\views/req-service/approval.blade.php ENDPATH**/ ?>