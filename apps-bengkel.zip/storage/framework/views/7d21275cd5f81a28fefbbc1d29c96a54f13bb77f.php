<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/vendor/dropzone/dist/min/dropzone.min.js"></script>
<script>
   $(function() {
    $('input[name="selectBengkel"]').on('click', function() {
      if ($(this).val() == 'rekanan') {
            $("#rekananText").show();
            $("#nonrekananText").hide();
        }
        else {
            $("#rekananText").hide();
            $("#nonrekananText").show();
         }
   
      });
   });
   $(function() {
    $('input[name="selectService"]').on('click', function() {
      if ($(this).val() == 'berkala') {
            $("#berkalaSelect").show();
            $("#partSelect").hide();
        }
        else {
            $("#berkalaSelect").hide();
            $("#partSelect").show();
         }
   
      });
   });
</script>
<?php echo $__env->make('layouts.headers.detailService', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid mt--7">
   <div class="row">
      <div class="col-xl-12">
         <div class="card">
            <div class="card-header">
               <div class="row align-items-center">
                  <div class="col-8">
                     <h3 class="mb-0">Informasi Kendaraan </h3>
                  </div>
               </div>
            </div>
            <div class="card-body">
               <?php if($service->status != 'On Warranty' || $service->status != 'Done'): ?>
               <form action="<?php echo e(route('update.detail', $service->no_service)); ?>" method="post" enctype="multipart/form-data">
               <?php endif; ?>
                  <?php echo csrf_field(); ?>
                  <div class="row">
                     <div class="col-md-12">
                        <div class="form-group">
                           <label class="form-control-label" for="input-address">No. Service</label>
                           <input id="vehicle" type="text" class="form-control" placeholder="Type to Search Nopol (ex: B1234ABC)" value="<?php echo e($service->no_service); ?>" readonly>
                        </div>
                        <div class="form-group">
                           <label class="form-control-label" for="input-address">Nopol</label>
                           <input id="vehicle" type="text" class="form-control" placeholder="Type to Search Nopol (ex: B1234ABC)" value="<?php echo e($service->nopol); ?>" readonly>
                        </div>
                        <div class="form-group">
                           <div class="row">
                              <div class="col-lg-6">
                                 <label class="form-control-label" for="input-city">Area</label>
                                 <input type="number" name="area" id="input-city" class="form-control" value="<?php echo e($service->area); ?>" readonly>
                              </div>
                              <div class="col-lg-6">
                                 <label class="form-control-label" for="input-city">Witel</label>
                                 <input type="text" name="witel" id="input-city" class="form-control" placeholder="Odoometer" value="<?php echo e($service->witel); ?>" readonly>
                              </div>
                           </div>
                        </div>
                        <div class="form-group">
                           <div class="row">
                              <div class="col-lg-6">
                                 <label class="form-control-label" for="input-city">Pool</label>
                                 <input type="text" name="pool" id="input-city" class="form-control" value="<?php echo e($service->pool); ?>" readonly>
                              </div>
                              <div class="col-lg-6">
                                 <label class="form-control-label" for="input-city">Dispatcher</label>
                                 <input type="text" id="input-city" class="form-control" placeholder="Odoometer" value="<?php echo e($service->kendaraan->dispatcher); ?>" readonly>
                              </div>
                           </div>
                        </div>
                        <div class="form-group">
                           <div class="row">
                              <div class="col-lg-6">
                                 <label class="form-control-label" for="input-city">Tahun</label>
                                 <input type="number" id="input-city" class="form-control" value="<?php echo e($service->kendaraan->tahun); ?>" readonly>
                              </div>
                              <div class="col-lg-6">
                                 <label class="form-control-label" for="input-city">Odoometer*</label>
                                 <?php if($service->status != 'Waiting'): ?>
                                 <input type="number" name="km" id="input-city" class="form-control" value=<?php echo e($service->km); ?> placeholder="Odoometer" readonly>
                                 <?php else: ?>
                                 <input type="number" name="km" id="input-city" class="form-control" value=<?php echo e($service->km); ?> placeholder="Odoometer">
                                 <?php endif; ?>
                              </div>
                           </div>
                        </div>
                        <div class="form-group">
                           <div class="row">
                              <div class="col-lg-6">
                                 <label class="form-control-label" for="input-address">No. Rangka</label>
                                 <input id="vehicle" type="text" class="form-control" placeholder="Type to Search Nopol (ex: B1234ABC)" value="<?php echo e($service->kendaraan->no_rangka); ?>" readonly>
                              </div>
                              <div class="col-lg-6">
                                 <label class="form-control-label" for="input-address">No. Mesin</label>
                                 <input id="vehicle" type="text" class="form-control" placeholder="Type to Search Nopol (ex: B1234ABC)" value="<?php echo e($service->kendaraan->no_mesin); ?>" readonly>
                              </div>
                           </div>
                        </div>
                        <div class="form-group">
                           <div class="row">
                              <div class="col-lg-6">
                                 <label class="form-control-label" for="input-address">Merk Kendaraan</label>
                                 <input id="vehicle" type="text" class="form-control" placeholder="Type to Search Nopol (ex: B1234ABC)" value="<?php echo e($service->kendaraan->merk); ?> <?php echo e($service->kendaraan->type); ?>" readonly>
                              </div>
                              <div class="col-lg-6">
                                 <label class="form-control-label" for="input-address">Warna</label>
                                 <input id="vehicle" type="text" class="form-control" placeholder="Type to Search Nopol (ex: B1234ABC)" value="<?php echo e($service->kendaraan->warna); ?>" readonly>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
            </div>
         </div>
      </div>
   </div>
   <div class="row mt-2">
      <div class="col-xl-12">
         <div class="card">
            <div class="card-header">
               <div class="row align-items-center">
                  <div class="col-6">
                     <h3 class="mb-0">Pilihan Bengkel </h3>
                  </div>
                  <div class="col-6">
                     <div class="float-sm-right">
                        <?php if($service->bengkel == NULL): ?>
                        <a href="#" data-toggle="modal" data-target="#exampleModal3" class="btn btn-sm btn-info" style="background-color:#808080;">Pilih Jenis Bengkel</a>
                        <?php endif; ?>
                     </div>
                  </div>
               </div>
            </div>
            <div class="card-body">
               <div class="table-responsive">
                  <table class="table table-bordered" style="width=100%;">
                     <thead>
                        <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#565656">
                           <th colspan="5">DETAIL BENGKEL</th>
                        </tr>
                        <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#565656">
                           <th width="10%">Action</th>   
                           <th width="45%">Jenis Bengkel</th>
                           <th width="45%">Nama Bengkel</th>
                        </tr>
                     </thead>
                     <tbody>
                        <?php if($service->jenis_bengkel != NULL): ?>
                        <tr class="text-center">
                           <th width="5%"><a href="#" onclick="return confirm('YAKIN HAPUS RINCIAN SERVICE?')" class="btn btn-sm btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a></th>
                           <?php if($service->jenis_bengkel == 'rekanan'): ?>   
                           <td width="40%">Bengkel Rekanan</td>
                           <?php else: ?>
                           <td width="40%">Bengkel Non Rekanan</td>
                           <?php endif; ?>
                           <td width="15%"><?php echo e($service->bengkel); ?></td>
                        </tr>
                        <?php endif; ?>
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="row mt-2">
      <div class="col-xl-12">
         <div class="card">
            <div class="card-header">
               <div class="row align-items-center">
                  <div class="col-6">
                     <h3 class="mb-0">Pilihan Service KHS</h3>
                  </div>
                  <div class="col-6">
                     <div class="float-sm-right">
			               <h4 class="mb-0">Ini adalah form terbaru, jika ingin melihat versi lama <a href="<?php echo e(route('request.olddetail', $service->no_service)); ?>">klik disini</a></h4>
                        <!-- <a href="#" data-toggle="modal" data-target="#exampleModal2" class="btn btn-sm btn-info" style="background-color:#808080;">Tambah Service Non KHS</a> -->
                        <a href="#" data-toggle="modal" data-target="#exampleModal" class="btn btn-sm btn-info" style="background-color:#808080;">Tambah Service</a>
                     </div>
                  </div>
               </div>
            </div>
            <div class="card-body">
               <div class="table-responsive">
                  <table class="table table-bordered" style="width=100%;">
                     <thead>
                        <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#565656">
                           <th colspan="5">DETAIL SERVICE</th>
                        </tr>
                        <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#565656">
                           <th width="5%">Action</th>   
                           <th width="40%">Deskripsi</th>
                           <th width="15%">Qty</th>
                           <th width="20%">Harga</th>
                           <th width="20%">Subtotal</th>
                        </tr>
                     </thead>
                     <tbody>
                        <?php $__currentLoopData = $rinciankhs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center">
                           <th width="5%"><a href="<?php echo e(route('delete.rincian', $r->id)); ?>" onclick="return confirm('YAKIN HAPUS RINCIAN SERVICE?')" class="btn btn-sm btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a></th>   
                           <td width="40%"><?php echo e($r->keterangan); ?></td>
                           <td width="15%"><?php echo e($r->qty); ?></td>
                           <td width="20%"><?php echo e(number_format($r->harga)); ?></td>
                           <td width="20%"><?php echo e(number_format($r->subtotal)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                     <tfoot>
                        <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#808080">
                           <th colspan="4">Total</th>
                           <th><?php echo e(number_format($totalkhs)); ?></th>
                        </tr>
                        <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#808080">
                           <th colspan="4">Grand Total KHS</th>
                           <th><?php echo e(number_format($totalkhs)); ?></th>
                        </tr>
                     </tfoot>
                  </table>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="row mt-2">
      <div class="col-xl-12">
         <div class="card">
            <div class="card-header">
               <div class="row align-items-center">
                  <div class="col-6">
                     <h3 class="mb-0">Pilihan Service Non KHS</h3>
                  </div>
                  <div class="col-6">
                     <div class="float-sm-right">
                        <a href="#" data-toggle="modal" data-target="#exampleModal2" class="btn btn-sm btn-info" style="background-color:#808080;">Tambah Service Non KHS</a>
                        <!-- <a href="#" data-toggle="modal" data-target="#exampleModal" class="btn btn-sm btn-info" style="background-color:#808080;">Tambah Service</a> -->
                     </div>
                  </div>
               </div>
            </div>
            <div class="card-body">
               <div class="table-responsive">
                  <table class="table table-bordered" style="width=100%;">
                     <thead>
                        <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#565656">
                           <th colspan="5">DETAIL SERVICE</th>
                        </tr>
                        <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#565656">
                           <th width="5%">Action</th>   
                           <th width="40%">Deskripsi</th>
                           <th width="15%">Qty</th>
                           <th width="20%">Harga</th>
                           <th width="20%">Subtotal</th>
                        </tr>
                     </thead>
                     <tbody>
                        <?php $__currentLoopData = $rinciannon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center">
                           <th width="5%"><a href="#" onclick="return confirm('YAKIN HAPUS RINCIAN SERVICE?')" class="btn btn-sm btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a></th>   
                           <td width="40%"><?php echo e($r->keterangan); ?></td>
                           <td width="15%"><?php echo e($r->qty); ?></td>
                           <td width="20%"><?php echo e(number_format($r->harga)); ?></td>
                           <td width="20%"><?php echo e(number_format($r->subtotal)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                     <tfoot>
                        <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#808080">
                           <th colspan="4">Total</th>
                           <th><?php echo e(number_format($totalnon)); ?></th>
                        </tr>
                        <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#808080">
                           <th colspan="4">PPn(10%)</th>
                           <th><?php echo e(number_format($service->ppn)); ?></th>
                        </tr>
                        <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#808080">
                           <th colspan="4">Grand Total Non KHS</th>
                           <th><?php echo e(number_format($totalnon + $service->ppn)); ?></th>
                        </tr>
                     </tfoot>
                  </table>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="row mt-2">
      <div class="col-xl-12">
         <div class="card">
            <div class="card-header">
               <div class="row align-items-center">
                  <div class="col-6">
                     <h3 class="mb-0">Grand Total</h3>
                  </div>
               </div>
            </div>
            <div class="card-body">
               <div class="table-responsive">
                  <table class="table table-bordered" style="width=100%;">
                     <thead>
                        <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#565656">
                           <th colspan="4">TOTAL PEMBAYARAN SERVICE <?php echo e($service->no_service); ?></th>
                        </tr>
                        <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#565656">
                           <th width="40%">Deskripsi</th>
                           <th width="20%">Total</th>
                           <th width="20%">PPn</th>
                           <th width="20%">Grand Total</th>
                        </tr>
                     </thead>
                     <tbody>
                        <tr class="text-center">
                           <td width="40%">Grand Total Service KHS</td>
                           <td width="20%"><?php echo e(number_format($totalkhs)); ?></td>
                           <td width="20%">0</td>
                           <td width="20%"><?php echo e(number_format($totalkhs)); ?></td>
                        </tr>
                        <tr class="text-center">
                           <td width="40%">Grand Total Service Non KHS</td>
                           <td width="20%"><?php echo e(number_format($totalnon)); ?></td>
                           <td width="20%"><?php echo e(number_format($service->ppn)); ?></td>
                           <td width="20%"><?php echo e(number_format($totalnon + $service->ppn)); ?></td>
                        </tr>
                     </tbody>
                     <tfoot>
                        <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#808080">
                           <th colspan="3">Total</th>
                           <th><?php echo e(number_format($service->total)); ?></th>
                        </tr>
                     </tfoot>
                  </table>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="row mt-2">
   
      <div class="col-xl-12">
         <div class="card">
            <div class="card-header">
               <div class="row align-items-center">
                  <div class="col-8">
                     <h3 class="mb-0">Bukti Sebelum Service</h3>
                  </div>
               </div>
            </div>
            <div class="card-body">
               <div class="dropzone dropzone-single" data-toggle="dropzone" data-dropzone-url="http://">
                  <?php if($service->status == 'Waiting'): ?>
                  <div class="fallback">
                     <div class="custom-file">
                        <input type="file" class="custom-file-input" id="uploadImg">
                        <label class="custom-file-label" for="dropzoneBasicUpload">Choose file</label>
                       
                     </div>
                  </div>
                  <?php endif; ?>
                  <div class="dz-preview dz-preview-single mt-2">
                     <div class="dz-preview-cover">
                        <?php if($service->foto != NULL): ?>
                        <img src="<?php echo e(asset('bukti-service/'.$service->foto->foto_before)); ?>" class="dz-preview-img"  id="previewImg" style="height:250px; width:400px;" data-dz-thumbnail>
			               <a target="_blank" href="<?php echo e(asset('bukti-service/'.$service->foto->foto_before)); ?>">Jika Foto tidak tampil, klik disini</a>
                        <?php else: ?>
                        <img class="dz-preview-img"  id="previewImg" style="height:250px; width:400px;" data-dz-thumbnail>
                        <?php endif; ?>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <?php if($service->status == 'On Warranty' || $service->status == 'Done'): ?>
   <div class="row mt-2">
      <div class="col-xl-12">
         <div class="card">
            <div class="card-header">
               <div class="row align-items-center">
                  <div class="col-8">
                     <h3 class="mb-0">Bukti Setelah Service</h3>
                  </div>
               </div>
            </div>
            <div class="card-body">
               <div class="dropzone dropzone-single" data-toggle="dropzone" data-dropzone-url="http://">
                  <div class="dz-preview dz-preview-single mt-2">
                     <div class="dz-preview-cover">
                        <?php if($service->foto != NULL): ?>
                        <img src="<?php echo e(asset('bukti-service/'.$service->foto->foto_after)); ?>" class="dz-preview-img"  id="previewImg" style="height:250px; width:400px;" data-dz-thumbnail>
                        <a target="_blank" href="<?php echo e(asset('bukti-service/'.$service->foto->foto_after)); ?>">Jika Foto tidak tampil, klik disini</a>
                        <?php else: ?>
                        <img class="dz-preview-img"  id="previewImg" style="height:250px; width:400px;" data-dz-thumbnail>
                        <?php endif; ?>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <?php endif; ?>
   <div class="row mt-4">
      <div class="col-12">
         <div class="float-right">
	         <?php if(Auth::user()->isDispatcher()): ?>
            <?php if($service->status == 'Waiting' || $service->status == 'On Service'): ?>
            <button type="submit" class="btn btn-primary">SUBMIT</button>
            <?php endif; ?>
            <?php endif; ?>
         </div>
         </form>
      </div>
   </div>
   <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Tambah Service</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <div class="modal-body">
            <form action="<?php echo e(route('store.rincian', $service->no_service)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
               <div class="row">
                  <div class="col-md-12">
                     <div class="form-group">
                        <label class="form-control-label" for="input-address">Jenis Service*</label>
                        <div class="form-check"> 
                           <input class="form-check-input" type="radio" value="berkala" name="selectService" >
                           <label class="form-check-label" for="rekanan" style="font-size:14px;"> 
                           Service Berkala
                           </label>
                        </div>
                        <div class="form-check">
                           <input class="form-check-input" type="radio" name="selectService" value="part">
                           <label class="form-check-label" for="nonrekanan" style="font-size:14px;"> 
                           Ganti Part
                           </label>
                        </div>
                     </div>
                     <div class="form-group" id="berkalaSelect" style="display:none;">
                        <div class="row">
                           <div class="col-6">
                              <label class="form-control-label" for="input-city">Paket Service*</label>
                           </div>
                           <div class="col-6">
                              <div class="float-right">
                                 <a href="#" data-toggle="modal" data-target="#exampleModal1" class="btn btn-sm btn-neutral" >Lihat Rincian Service</a>
                              </div>
                           </div>
                        </div>
                        <select name="keterangan" class="form-control">
                           <option value="" selected disabled>Pilih Paket Service</option>
                           
                           <?php $__currentLoopData = $stokservice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($ss->kode); ?>"><?php echo e($ss->nama_service); ?> - Rp.<?php echo e(number_format($ss->harga)); ?>,-</option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                     </div>
                     <div class="form-group" id="partSelect" style="display:none;">
                        <label class="form-control-label" for="input-city">Part*</label>
                        <input  value="" name="keterangan1" class="form-control" placeholder="Type to Search Sparpert.." list="listPart">
                           <datalist id="listPart" name="bengkel">
                              <?php $__currentLoopData = $stokpart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($sp->kode); ?>"><?php echo e($sp->nama); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </datalist>
                        
                     </div>
                     <div class="form-group">
                        <label class="form-control-label" for="input-city">Qty*</label>
                        <input type="number" name="qty"  class="form-control" placeholder="Qty">
                     </div>
                  </div>
               </div>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Submit</button>
            </form>
         </div>
      </div>
   </div>
</div>
<div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Tambah Service</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <div class="modal-body">
            <div class="table-responsive">
               <table class="table table-bordered" width="100%">
                  <thead>
                     <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#565656">
                        <th colspan="4">Detail Pekerjaan Service</th>
                     </tr>
                     <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#565656">
                        <th width="25%">Nama Service</th>
                        <th width="25%">Nama Barang</th>
                        <th width="35%">Spesifikasi</th>
                        <th width="15%">Harga</th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php $__currentLoopData = $stokservice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php $__currentLoopData = $s->rincianStok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr class="text-center">
                        <td><?php echo e($s->nama_service); ?></td>
                        <td><?php echo e($rs->nama_barang); ?></td>
                        <td><?php echo e($rs->spesifikasi); ?></td>
                        <td><?php echo e(number_format($rs->harga)); ?></td>
                     </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
               </table>
            </div>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
         </div>
      </div>
   </div>
</div>
<div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Tambah Service</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <div class="modal-body">
            <form action="<?php echo e(route('store.nonkhs', $service->no_service)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
               <div class="row">
                  <div class="col-md-12">
                     <div class="form-group">
                        <label class="form-control-label" for="input-city">Nama Part/Service</label>
                        <input  value="" name="nama" type="text" class="form-control" placeholder="Nama Service">
                     </div>
                     <div class="form-group">
                        <label class="form-control-label" for="input-city">Harga</label>
                        <input type="number" name="harga"  class="form-control" placeholder="Harga">
                     </div>
                     <div class="form-group">
                        <label class="form-control-label" for="input-city">Qty</label>
                        <input type="number" name="qty"  class="form-control" placeholder="Qty">
                     </div>
                  </div>
               </div>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Submit</button>
            </form>
         </div>
      </div>
   </div>
</div>
<div class="modal fade" id="exampleModal3" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Tambah Bengkel</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <div class="modal-body">
            <form action="<?php echo e(route('store.bengkel', $service->no_service)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
               <div class="row">
                  <div class="col-md-12">
                     <div class="form-group">
                           <label class="form-control-label" for="input-address">Jenis Bengkel*</label>
                           <div class="form-check"> 
                              <input class="form-check-input" type="radio" value="rekanan" name="selectBengkel" >
                              <label class="form-check-label" for="rekanan" style="font-size:14px;"> 
                              Bengkel Rekanan
                              </label>
                              
                           </div>
                           <div class="form-check">
                              <input class="form-check-input" type="radio" name="selectBengkel" value="nonrekanan">
                              <label class="form-check-label" for="nonrekanan" style="font-size:14px;"> 
                              Bengkel Non-Rekanan
                              </label>
                           </div>
                        </div>
                        <div class="form-group" id="rekananText" style="display:none;">
                           <label class="form-control-label" for="input-city">Nama Bengkel Rekanan*</label>
                           <input id="bengkel" value="" name="bengkel1" class="form-control" placeholder="Type to Search Bengkel.." list="datalistOptions">
                           <datalist id="datalistOptions" name="bengkel">
                              <?php $__currentLoopData = $bengkel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($b->nama_bengkel); ?>"><?php echo e($b->nama_bengkel); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </datalist>
                           <label class="form-check-label" style ="font-size:12px;color:red;" for="input-city">Rekomendasi Bengkel : <?php echo e($kendaraan->nama_bengkel); ?></label>
                        </div>
                        <div class="form-group" id="nonrekananText" style="display:none;">
                           <label class="form-control-label" for="input-city">Nama*</label>
                           <input name="bengkel" type="text" id="input-city" class="form-control" placeholder="Nama Bengkel">
                        </div>
                  </div>
               </div>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Submit</button>
            </form>
         </div>
      </div>
   </div>
</div>
<script type="text/javascript">
   function readURL(input) {
       if (input.files && input.files[0]) {
           var reader = new FileReader();
           
           reader.onload = function (e) {
               $('#previewImg').attr('src', e.target.result);
           }
           reader.readAsDataURL(input.files[0]);
       }
   }
   $("#uploadImg").change(function(){
       readURL(this);
   });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mywe9397/public_html/klikbengkel.id/resources/views/req-service/detail.blade.php ENDPATH**/ ?>