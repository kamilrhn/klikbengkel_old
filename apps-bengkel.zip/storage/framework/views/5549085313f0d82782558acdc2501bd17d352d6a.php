<div class="header pb-8 pt-5 pt-md-8" style="background-color:#ed1c24;">
    <div class="container-fluid">
        <div class="header-body">
            <!-- Card stats -->
            <div class="row align-items-center ">
                <div class="col-lg-6 col-7">
                    <?php if(Auth::user()->isPusat()): ?>
                    <h6 class="h2 text-white d-inline-block mb-0">DASHBOARD KBM AREA <?php echo e(request()->segment(count(request()->segments()))); ?></h6>
                    <?php elseif(Auth::user()->isAsman()): ?>
                    <h6 class="h2 text-white d-inline-block mb-4">DASHBOARD KBM AREA <?php echo e(Auth::user()->resp); ?> </h6>
                    <?php else: ?>
                    <h6 class="h2 text-white d-inline-block mb-4">DASHBOARD KBM <?php echo e(Auth::user()->resp); ?> </h6>
                    <?php endif; ?>
                </div>
                <div class="col-lg-6 col 7">
                    <?php if(Auth::user()->isPusat() || Auth::user()->isAdmin()): ?>
                    <div class="form-group">
                        <label for="" class="form-control-label text-white">Pilih Area</label>
                        <select name="" id="" class="form-control" onchange="location = this.value">
                            <option value="#" selected disabled>Pilih Area</option>
                            <option value="<?php echo e(route('home')); ?>"   >All</option>
                            <option value="<?php echo e(route('home.area', 1)); ?>"   >Area 1</option>
                            <option value="<?php echo e(route('home.area', 2)); ?>"   >Area 2</option>
                            <option value="<?php echo e(route('home.area', 3)); ?>"   >Area 3</option>
                            <option value="<?php echo e(route('home.area', 4)); ?>"   >Area 4</option>
                            <option value="<?php echo e(route('home.area', 5)); ?>"   >Area 5</option>
                            <option value="<?php echo e(route('home.area', 6)); ?>"   >Area 6</option>
                            <option value="<?php echo e(route('home.area', 7)); ?>"   >Area 7</option>
                        </select>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-3 col-lg-6">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Jumlah Kendaraan</h5>
                                    <span class="h2 font-weight-bold mb-0"><?php echo e($kendaraan); ?></span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-danger text-white rounded-circle shadow">
                                        <i class="fas fa-car"></i>
                                    </div>
                                </div>
                            </div>
                            <!-- <p class="mt-3 mb-0 text-muted text-sm">
                                <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
                                <span class="text-nowrap">Since last month</span>
                            </p> -->
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Kendaraan On Services</h5>
                                    <span class="h2 font-weight-bold mb-0"><?php echo e($serviceOngoing); ?></span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-warning text-white rounded-circle shadow">
                                        <i class="fas fa-car-crash"></i>
                                    </div>
                                </div>
                            </div>
                            <!-- <p class="mt-3 mb-0 text-muted text-sm">
                                <span class="text-danger mr-2"><i class="fas fa-arrow-down"></i> 3.48%</span>
                                <span class="text-nowrap">Since last week</span>
                            </p> -->
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Kendaraan On Warranty</h5>
                                    <span class="h2 font-weight-bold mb-0"><?php echo e($serviceOnwarran); ?></span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-yellow text-white rounded-circle shadow">
                                        <i class="fas fa-receipt"></i>
                                    </div>
                                </div>
                            </div>
                            <!-- <p class="mt-3 mb-0 text-muted text-sm">
                                <span class="text-warning mr-2"><i class="fas fa-arrow-down"></i> 1.10%</span>
                                <span class="text-nowrap">Since yesterday</span>
                            </p> -->
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Kendaraan Done</h5>
                                    <span class="h2 font-weight-bold mb-0"><?php echo e($serviceDone); ?></span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-info text-white rounded-circle shadow">
                                        <i class="fas fa-check-circle"></i>
                                    </div>
                                </div>
                            </div>
                            <!-- <p class="mt-3 mb-0 text-muted text-sm">
                                <span class="text-success mr-2"><i class="fas fa-arrow-up"></i> 12%</span>
                                <span class="text-nowrap">Since last month</span>
                            </p> -->
                        </div>
                    </div>
                </div>
            </div>
            <div class="row align-right mb--5">
                <div class="col-lg-12 col 7">
                    <form action="<?php echo e(route('part.search')); ?>" method="get" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                         <div class="row">
                             <div class="col-9">
                                 <div class="form-group">
                                     <label class="form-control-label text-white" for="input-city">Pilih Service</label>
                                     <select name="search" class="form-control">
                                         <option value="" selected disabled>Pilih Service</option> 
                                         <?php $__currentLoopData = $rincian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($r->keterangan); ?>"><?php echo e($r->keterangan); ?></option> 
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     </select>
                                 </div>
                             </div>
                             <div class="col-3">
                                 <div class="form-group">
                                     <br>
                                 <button type="submit" class="btn btn-md btn-primary btn-block" style="background-color:#808080;">Search</button>
                                 </div>
                             </div>
                         </div>
                    </form>
                 </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\apps-bengkel\resources\views/layouts/headers/cards.blade.php ENDPATH**/ ?>