
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.settings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid mt--7">
   <div class="row">
      <div class="col">
         <div class="card">
            <!-- Card header -->
            <div class="card-header border-0">
              <h3 class="mb-0">Konfigurasi Validasi</h3>
            </div>
            <!-- Light table -->
            <div class="card-body">
                <?php if($area->setting == null): ?>
                <form action="<?php echo e(route('setting.create')); ?>" method="post" enctype="multipart/form-data">
                <?php else: ?>
                <form action="#" method="get" enctype="multipart/form-data">
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-6">
                            <label class="form-control-label" for="input-address">Selisih Odometer</label>
                            <?php if($area->setting != null): ?>
                            <input id="vehicle" type="number" name="km" class="form-control" placeholder="Selisih Odometer" value="<?php echo e($setting->km); ?>" >
                            <?php else: ?>
                            <input id="vehicle" name="km" type="number" class="form-control" placeholder="Selisih Odoometer" value="" >
                            <?php endif; ?>
                        </div>
                        <div class="col-lg-6">
                            <label class="form-control-label" for="input-address">Selisih Bulan</label>
                            <?php if($area->setting != null): ?>
                            <input id="vehicle" name="waktu" type="number" class="form-control" placeholder="Selisih Bulan" value="<?php echo e($setting->waktu); ?>" >
                            <?php else: ?>
                            <input id="vehicle" name="waktu" type="number" class="form-control" placeholder="Selisih Bulan" value="" >
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-12">
                            <div class="float-sm-right">
                                <button type="submit" class="btn btn-primary">SUBMIT</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
          </div>
      </div>
   </div>
   <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mywe9397/public_html/klikbengkel.id/resources/views/settings/index.blade.php ENDPATH**/ ?>