
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/vendor/dropzone/dist/min/dropzone.min.js"></script>
<script>
   $(function() {
    $('input[name="selectBengkel"]').on('click', function() {
      if ($(this).val() == 'rekanan') {
            $("#rekananText").show();
            $("#nonrekananText").hide();
        }
        else {
            $("#rekananText").hide();
            $("#nonrekananText").show();
         }
   
      });
   });
   $(function() {
    $('input[name="selectService"]').on('click', function() {
      if ($(this).val() == 'berkala') {
            $("#berkalaSelect").show();
            $("#partSelect").hide();
        }
        else {
            $("#berkalaSelect").hide();
            $("#partSelect").show();
         }
   
      });
   });
</script>
<?php echo $__env->make('layouts.headers.detailService', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid mt--7">
   <div class="row">
      <div class="col-xl-12">
         <div class="card">
            <div class="card-header">
               <div class="row align-items-center">
                  <div class="col-8">
                     <h3 class="mb-0">Informasi Kendaraan </h3>
                  </div>
               </div>
            </div>
            <div class="card-body">
               <?php if($service->status != 'On Warranty' || $service->status != 'Done'): ?>
               <form action="<?php echo e(route('cancel.process', $service->no_service)); ?>" method="get" enctype="multipart/form-data">
               <?php endif; ?>
                  <?php echo csrf_field(); ?>
                  <div class="row">
                     <div class="col-md-12">
                        <div class="form-group">
                           <label class="form-control-label" for="input-address">No. Service</label>
                           <input id="vehicle" type="text" class="form-control" placeholder="Type to Search Nopol (ex: B1234ABC)" value="<?php echo e($service->no_service); ?>" readonly>
                        </div>
                        <div class="form-group">
                           <label class="form-control-label" for="input-address">Nopol</label>
                           <input id="vehicle" type="text" class="form-control" placeholder="Type to Search Nopol (ex: B1234ABC)" value="<?php echo e($service->nopol); ?>" readonly>
                        </div>
                        <div class="form-group">
                           <div class="row">
                              <div class="col-lg-6">
                                 <label class="form-control-label" for="input-city">Area</label>
                                 <input type="number" name="area" id="input-city" class="form-control" value="<?php echo e($service->area); ?>" readonly>
                              </div>
                              <div class="col-lg-6">
                                 <label class="form-control-label" for="input-city">Witel</label>
                                 <input type="text" name="witel" id="input-city" class="form-control" placeholder="Odoometer" value="<?php echo e($service->witel); ?>" readonly>
                              </div>
                           </div>
                        </div>
                        <div class="form-group">
                           <div class="row">
                              <div class="col-lg-6">
                                 <label class="form-control-label" for="input-city">Pool</label>
                                 <input type="text" name="pool" id="input-city" class="form-control" value="<?php echo e($service->pool); ?>" readonly>
                              </div>
                              <div class="col-lg-6">
                                 <label class="form-control-label" for="input-city">Dispatcher</label>
                                 <input type="text" id="input-city" class="form-control" placeholder="Odoometer" value="<?php echo e($service->kendaraan->dispatcher); ?>" readonly>
                              </div>
                           </div>
                        </div>
                        <div class="form-group">
                           <div class="row">
                              <div class="col-lg-6">
                                 <label class="form-control-label" for="input-city">Tahun</label>
                                 <input type="number" id="input-city" class="form-control" value="<?php echo e($service->kendaraan->tahun); ?>" readonly>
                              </div>
                              <div class="col-lg-6">
                                 <label class="form-control-label" for="input-city">Odoometer*</label>
                                 <?php if($service->status != 'Waiting'): ?>
                                 <input type="number" name="km" id="input-city" class="form-control" value=<?php echo e($service->km); ?> placeholder="Odoometer" readonly>
                                 <?php else: ?>
                                 <input type="number" name="km" id="input-city" class="form-control" value=<?php echo e($service->km); ?> placeholder="Odoometer">
                                 <?php endif; ?>
                              </div>
                           </div>
                        </div>
                        <div class="form-group">
                           <div class="row">
                              <div class="col-lg-6">
                                 <label class="form-control-label" for="input-address">No. Rangka</label>
                                 <input id="vehicle" type="text" class="form-control" placeholder="Type to Search Nopol (ex: B1234ABC)" value="<?php echo e($service->kendaraan->no_rangka); ?>" readonly>
                              </div>
                              <div class="col-lg-6">
                                 <label class="form-control-label" for="input-address">No. Mesin</label>
                                 <input id="vehicle" type="text" class="form-control" placeholder="Type to Search Nopol (ex: B1234ABC)" value="<?php echo e($service->kendaraan->no_mesin); ?>" readonly>
                              </div>
                           </div>
                        </div>
                        <div class="form-group">
                           <div class="row">
                              <div class="col-lg-6">
                                 <label class="form-control-label" for="input-address">Merk Kendaraan</label>
                                 <input id="vehicle" type="text" class="form-control" placeholder="Type to Search Nopol (ex: B1234ABC)" value="<?php echo e($service->kendaraan->merk); ?> <?php echo e($service->kendaraan->type); ?>" readonly>
                              </div>
                              <div class="col-lg-6">
                                 <label class="form-control-label" for="input-address">Warna</label>
                                 <input id="vehicle" type="text" class="form-control" placeholder="Type to Search Nopol (ex: B1234ABC)" value="<?php echo e($service->kendaraan->warna); ?>" readonly>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
            </div>
         </div>
      </div>
   </div>
   <div class="row mt-2">
      <div class="col-xl-12">
         <div class="card">
            <div class="card-header">
               <div class="row align-items-center">
                  <div class="col-8">
                     <h3 class="mb-0">Pilihan Service </h3>
                  </div>
               </div>
            </div>
            <div class="card-body">
               <div class="table-responsive">
                  <table class="table table-bordered" style="width=100%;">
                     <thead>
                        <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#565656">
                           <th colspan="5">DETAIL SERVICE</th>
                        </tr>
                        <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#565656">
                           <th width="5%">Action</th>   
                           <th width="40%">Deskripsi</th>
                           <th width="15%">Qty</th>
                           <th width="20%">Harga</th>
                           <th width="20%">Subtotal</th>
                        </tr>
                     </thead>
                     <tbody>
                        <?php $__currentLoopData = $service->rincian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center">
                           <?php if($service->status == 'Waiting'): ?>
                           <th width="5%"><a href="<?php echo e(route('delete.rincian', $r->id)); ?>" onclick="return confirm('YAKIN HAPUS RINCIAN SERVICE?')" class="btn btn-sm btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a></th>
                           <?php else: ?>
                           <th width="5%">-</th>
                           <?php endif; ?>   
                           <td width="40%"><?php echo e($r->keterangan); ?></td>
                           <td width="15%"><?php echo e($r->qty); ?></td>
                           <td width="20%"><?php echo e(number_format($r->harga)); ?></td>
                           <td width="20%"><?php echo e(number_format($r->subtotal)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                     <tfoot>
                        <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#808080">
                           <th colspan="4">Total</th>
                           <th><?php echo e(number_format($service->subtotal)); ?></th>
                        </tr>
                        <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#808080">
                           <th colspan="4">PPn(10%)</th>
                           <th><?php echo e(number_format($service->ppn)); ?></th>
                        </tr>
                        <tr class="teal darken-1 white-text text-center" style="color:white;font-weight:bolder;background-color:#808080">
                           <th colspan="4">Grand Total</th>
                           <th><?php echo e(number_format($service->total)); ?></th>
                        </tr>
                     </tfoot>
                  </table>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="row mt-2">
   <div class="col-xl-6">
         <div class="card">
            <div class="card-header">
               <div class="row align-items-center">
                  <div class="col-8">
                     <h3 class="mb-0">Informasi Bengkel </h3>
                  </div>
               </div>
            </div>
            <div class="card-body">
                  <div class="row">
                     <div class="col-md-12">
                        <div class="form-group">
                            <label class="form-control-label" for="input-address">Jenis Bengkel</label>
                            <input id="vehicle" name="selectBengkel" type="text" class="form-control" placeholder="Type to Search Nopol (ex: B1234ABC)" value="<?php echo e($service->jenis_bengkel); ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label class="form-control-label" for="input-address">Nama Bengkel</label>
                            <input id="vehicle" name="bengkel" type="text" class="form-control" placeholder="Type to Search Nopol (ex: B1234ABC)" value="<?php echo e($service->bengkel); ?>" readonly>
                        </div>
                     </div>
                  </div>
            </div>
         </div>
      </div>
      <div class="col-xl-6">
         <div class="card">
            <div class="card-header">
               <div class="row align-items-center">
                  <div class="col-8">
                     <h3 class="mb-0">Bukti Sebelum Service</h3>
                  </div>
               </div>
            </div>
            <div class="card-body">
               <div class="dropzone dropzone-single" data-toggle="dropzone" data-dropzone-url="http://">
                  <?php if($service->status == 'Waiting'): ?>
                  <div class="fallback">
                     <div class="custom-file">
                        <input type="file" class="custom-file-input" id="uploadImg">
                        <label class="custom-file-label" for="dropzoneBasicUpload">Choose file</label>
                       
                     </div>
                  </div>
                  <?php endif; ?>
                  <div class="dz-preview dz-preview-single mt-2">
                     <div class="dz-preview-cover">
                        <?php if($service->foto != NULL): ?>
                        <img src="<?php echo e(asset('bukti-service/'.$service->foto->foto_before)); ?>" class="dz-preview-img"  id="previewImg" style="height:250px; width:400px;" data-dz-thumbnail>
                        <?php else: ?>
                        <img class="dz-preview-img"  id="previewImg" style="height:250px; width:400px;" data-dz-thumbnail>
                        <?php endif; ?>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <?php if($service->status == 'On Warranty' || $service->status == 'Done'): ?>
   <div class="row mt-2">
      <div class="col-xl-6">
         <div class="card">
            <div class="card-header">
               <div class="row align-items-center">
                  <div class="col-8">
                     <h3 class="mb-0">Bukti Setelah Service</h3>
                  </div>
               </div>
            </div>
            <div class="card-body">
               <div class="dropzone dropzone-single" data-toggle="dropzone" data-dropzone-url="http://">
                  <div class="dz-preview dz-preview-single mt-2">
                     <div class="dz-preview-cover">
                        <?php if($service->foto != NULL): ?>
                        <img src="<?php echo e(asset('bukti-service/'.$service->foto->foto_before)); ?>" class="dz-preview-img"  id="previewImg" style="height:250px; width:400px;" data-dz-thumbnail>
                        <?php else: ?>
                        <img class="dz-preview-img"  id="previewImg" style="height:250px; width:400px;" data-dz-thumbnail>
                        <?php endif; ?>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <?php endif; ?>
   <div class="row mt-4">
      <div class="col-12">
         <div class="float-right">
	         <?php if(Auth::user()->isDispatcher()): ?>
            <?php if($service->status == 'Waiting' || $service->status == 'On Service'): ?>
            <button type="submit" class="btn btn-md btn-danger">Cancel Service</button>
            <?php endif; ?>
            <?php endif; ?>
         </div>
         </form>
      </div>
   </div>
   <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<script type="text/javascript">
   function readURL(input) {
       if (input.files && input.files[0]) {
           var reader = new FileReader();
           
           reader.onload = function (e) {
               $('#previewImg').attr('src', e.target.result);
           }
           reader.readAsDataURL(input.files[0]);
       }
   }
   $("#uploadImg").change(function(){
       readURL(this);
   });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apps-bengkel\resources\views/req-service/cancel-detail.blade.php ENDPATH**/ ?>