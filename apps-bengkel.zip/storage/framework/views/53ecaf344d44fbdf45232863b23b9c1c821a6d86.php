
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.headers.payment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/vendor/dropzone/dist/min/dropzone.min.js"></script>
<div class="container-fluid mt--7">
    <div class="row">
       <div class="col">
            <div class="card">
                <div class="card-header border-0">
                    <h3 class="mb-0">Submission Payment</h3>
                </div>
                <div class="table-responsive">
                    <table class="table align-items-center table-flush">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col" class="sort" data-sort="name">Tanggal Selesai</th>
                                <th scope="col" class="sort" data-sort="name">No. Service</th>
                                <th scope="col" class="sort" data-sort="name">Jenis Service</th>
                                <th scope="col" class="sort" data-sort="name">Nopol</th>
                                <th scope="col" class="sort" data-sort="budget">Subtotal</th>
                                <th scope="col" class="sort" data-sort="budget">PPn</th>
                                <th scope="col" class="sort" data-sort="budget">Grand Total</th>
                                <th scope="col" class="sort" data-sort="budget">Status</th>
                                <th scope="col" class="sort" data-sort="budget">Action</th>
                            </tr>
                        </thead>
                        <tbody class="list">
                            <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($s->invoice->tanggal); ?></td>
                                <td><?php echo e($s->no_service); ?></td>
                                <?php if($s->reg_urg != NULL): ?>
                                <td><?php echo e($s->reg_urg); ?></td>
                                <?php else: ?>
                                <td>-</td>
                                <?php endif; ?>
                                <td><?php echo e($s->nopol); ?></td>  
                                <td><?php echo e(number_format($s->subtotal)); ?></td>
                                <td><?php echo e(number_format($s->ppn)); ?></td>
                                <td><?php echo e(number_format($s->total)); ?></td>
                                <?php if($s->status == 'Waiting'): ?>
                                <td><span class="badge badge-danger" style="color:#white">Waiting</span></td>
                                <?php elseif($s->status == 'On Service'): ?>
                                <td><span class="badge badge-info" style="color:#white">On Service</span></td>
                                <?php elseif($s->status == 'On Warranty'): ?>
                                <td><span class="badge badge-warning" style="color:#white">On Warranty</span></td>
                                <?php elseif($s->status == 'Done'): ?>
                                <td><span class="badge badge-success" style="color:#white">Done</span></td>
                                <?php elseif($s->status == 'Request Cancel'): ?>
                                <td><span class="badge badge-success" style="color:#white">Request Cancel</span></td>
                                <?php else: ?>
                                <td><span class="badge badge-danger" style="color:#white">Declined</span></td>
                                <?php endif; ?>
                                <td>
                                    <a href="" class="btn btn-sm btn-warning" data-toggle="modal" data-target="#ajukan-<?php echo e($s->no_service); ?>"><i class="far fa-credit-card"></i> Ajukan</a>
                                    <a href="#" class="btn btn-sm btn-info"><i class="fas fa-tasks"></i> Proses</a>
                                </td>
                            </tr>
                            <div class="modal fade" id="ajukan-<?php echo e($s->no_service); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <h5 class="modal-title" id="exampleModalLabel">Form Pengajuan Pembayaran Service <?php echo e($s->no_service); ?></h5>
                                      <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="<?php echo e(route('store.payment')); ?>" method="post" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label class="form-control-label" for="input-address">No. Service</label>
                                                <input id="nominal" type="text" name="no_service" class="form-control"
                                                    placeholder="Masukkan Nominal Sesuai Nota" value="<?php echo e($s->no_service); ?>" readonly>
                                            </div>
                                            <div class="form-group">
                                                <label class="form-control-label" for="input-address">Total</label>
                                                <input id="nominal" type="number" name="nominal_nota" class="form-control"
                                                    placeholder="Masukkan Nominal Sesuai Nota">
                                            </div>
                                            <div class="form-group">
                                                <label class="form-control-label" for="input-address">Nama Rekening</label>
                                                <input id="nominal" type="text" name="nama_rekening" class="form-control"
                                                    placeholder="Masukkan Nama Rekening">
                                            </div>
                                            <div class="form-group">
                                                <label class="form-control-label" for="input-address">No. Rekening</label>
                                                <input id="nominal" type="number" name="no_rekening" class="form-control"
                                                    placeholder="Masukkan Nomor Rekening">
                                            </div>
                                            <div class="form-group">
                                                <label class="form-control-label" for="input-address">Nama Bank</label>
                                                <input id="nominal" type="text" name="nama_bank" class="form-control"
                                                    placeholder="Masukkan Nama Bank">
                                            </div>
                                            <div class="form-group">
                                                <label class="form-control-label" for="input-address">File Nota</label>
                                                <input id="nominal" type="file" name="file" class="form-control"
                                                    placeholder="Masukkan Nama Bank">
                                            </div>
                                    </div>
                                    <div class="modal-footer">
                                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                      <button type="submit" class="btn btn-primary">Submit</button>
                                    </form>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer py-4">
                    <nav aria-label="...">
                        <div class="float-sm-right">
                            <ul class="pagination mb-0">
                                <li class="page-item">
                                    <?php echo e($service->links()); ?>

                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
       </div>
    </div>
    <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apps-bengkel\resources\views/invoice/listPayment.blade.php ENDPATH**/ ?>